<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="IE=edge" http-equiv="X-UA-Compatible">
  <meta content="width=device-width,initial-scale=1" name="viewport">
  <meta content="Page description" name="description">
  <meta name="google" content="notranslate" />
  <meta content="" name="author">

  
  <meta name="msapplication-tap-highlight" content="no">
  
  <link href="" rel="">
  <link href="" rel="">



  <title>Admin</title>  

<link href="./main.82cfd66e.css" rel="stylesheet">
<link href="./background" rel="stylesheet">
</head>

<body style='font-weight: normal;' >
<p>
<!-- Add your content of header -->
<header class="">
  <div class="navbar navbar-default visible-xs">
    <button type="button" class="navbar-toggle collapsed">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
   <a href="./loginhtmlcopy.php"> MA Country Club</a>
  </div>

  <nav class="sidebar">
    <div class="navbar-collapse" id="navbar-collapse">
      <div class="site-header hidden-xs">
          <a class="site-brand" href="./loginhtmlcopy.php" title="">
            <img class="img-responsive site-logo" alt="" src="./ResourcesNEW/logo.jpg">
            MA Country Club
          </a>
        <p>Where Luxury Meets Comfort.</p>
      </div>
      <ul class="nav">
        <a href="./admin.php" title="">Home</a></li>
        <li><a href="./AppBody/memberdetails.php" title="">Member Details</a></li>
        <li><a href="./AppBody/events.php" title="">Events</a></li>
        <li><a href="./AppBody/sports.php" title="">Sports</a></li>
        <li><a href="./AppBody/competitions.php" title="">Competitions</a></li>
        <li><a href="./AppBody/partyhall.php" title="">Party Hall</a></li>
        <li><a href="./AppBody/movies.php" title="">Movies</a></li>
        <li><a href="./AppBody/advertisment.php" title="">Advertisment</a></li>
        <li><a href="./AppBody/blog.php" title="">Blog</a></li>
        <li><a href="./AppBody/monthbill.php" title="">Bill</a></li>
        <li><a href="./AppBody/admindetails.php" title="">Admin</a></li>

      </ul>

      <nav class="nav-footer">
        <p class="nav-footer-social-buttons">
          <a class="fa-icon" href="https://www.instagram.com/ayush.dhiman_" title="">
            <i class="fa fa-instagram"></i>
          </a>
          <a class="fa-icon" href="https://dribbble.com/" title="">
            <i class="fa fa-dribbble"></i>
          </a>
          <a class="fa-icon" href="https://twitter.com/" title="">
            <i class="fa fa-twitter"></i>
          </a>
        </p>
        <p>© Untitled | Website created by Create website by Ayush Dhiman</a>
      </nav>  
    </div> 
  </nav>
</header>
<main class="" id="main-collapse">
<h1 style='margin: auto;
  width: 60%;border: 5px solid khaki;padding: 5px;text-align:center;border-collapse: collapse; font-size: 30px;min-width: 400px;border-radius: 5px 5px 0 0;overflow: hidden;box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);'>
ADMIN LOGIN
</h1>
<br><br>



    <img src="./ResourcesNEW/a.jpg" alt="Snow" width="90%" ><br>
  
  
    <img src=./ResourcesNEW/b.jpg alt="Forest"width="90%" ><br>
  
  
    <img src=./ResourcesNEW/c.jpg alt="Forest"width="90%"><br>
  
  
    <img src=./ResourcesNEW/g.jpg alt="Forest" width="90%"><br>
 
    <img src=./ResourcesNEW/e.jpg alt="Forest" width="90%"><br>
 
    <img src=./ResourcesNEW/f.jpg alt="Forest" width="90%"><br>
  
    <img src=./ResourcesNEW/d.jpg alt="Forest" width="90%"><br>
    <img src=./ResourcesNEW/h.jpg alt="Forest" width="90%"><br>
    <img src=./ResourcesNEW/i.jpg alt="Forest" width="90%"><br>
  
  
 
</p>





 