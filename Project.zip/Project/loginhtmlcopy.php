<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <title>MA Country Club</title>
    <link rel="stylesheet" href="background.css" />
  </head>

  <body >
    <form action="login.php" method="POST">
    
      <div class="login-box" >
      
        <h1>Login</h1>
        <div class="textbox" >
          <i class="fas fa-user"></i>
          <input type="text" placeholder="Username" name="USEX" />
        </div>

        <div class="textbox">
          <i class="fas fa-lock"></i>
          <input type="password" placeholder="Password" name="PSEX" />
        </div>

        <input type="submit" value="Submit" name="submitname" />
      </div>
      </div>
    </form>
  </body>
</html>



